<?php
if (!defined('ABSPATH')) {
    exit;
}

function mirruba_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script'));
}
add_action('after_setup_theme', 'mirruba_theme_setup');

function mirruba_register_elementor_locations($elementor_theme_manager) {
    if (method_exists($elementor_theme_manager, 'register_all_core_location')) {
        $elementor_theme_manager->register_all_core_location();
    }
}
add_action('elementor/theme/register_locations', 'mirruba_register_elementor_locations');

function mirruba_theme_assets() {
    $theme_version = wp_get_theme()->get('Version');

    wp_enqueue_style(
        'mirruba-theme-style',
        get_stylesheet_uri(),
        array(),
        $theme_version
    );

    // Load original static app assets so frontend matches old site exactly.
    wp_enqueue_style('boxicons', 'https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css', array(), null);
    wp_enqueue_style('primeicons', 'https://unpkg.com/primeicons/primeicons.css', array(), null);
    wp_enqueue_style('mirruba-legacy-main', home_url('/static/css/main.5789f0fd.css'), array(), null);

    wp_enqueue_script(
        'mirruba-legacy-main-js',
        home_url('/static/js/main.e5398a45.js'),
        array(),
        null,
        true
    );

    wp_add_inline_script(
        'mirruba-legacy-main-js',
        'window.WOO_PRODUCTS_CONFIG = { storeUrl: "' . esc_js(home_url()) . '", perPage: 24, currencyPrefix: "$", shopPath: "/allProducts" };',
        'before'
    );

    // Woo products renderer (fills #woo-products-root using Store API).
    wp_enqueue_script(
        'mirruba-woo-products-legacy',
        home_url('/static/js/woo-products.js'),
        array(),
        null,
        true
    );
}
add_action('wp_enqueue_scripts', 'mirruba_theme_assets');

function mirruba_legacy_footer_scripts() {
    ?>
    <script src="https://unpkg.com/@dotlottie/player-component@latest/dist/dotlottie-player.mjs" type="module"></script>
    <script>
    (function () {
      function getCartCount() {
        try {
          var raw = localStorage.getItem('cartItems');
          var items = raw ? JSON.parse(raw) : [];
          if (!Array.isArray(items)) return 0;
          var total = 0;
          for (var i = 0; i < items.length; i += 1) {
            var it = items[i] || {};
            var q = Number(it.quantity || it.count || 1);
            if (!Number.isFinite(q) || q < 1) q = 1;
            total += q;
          }
          return total;
        } catch (e) {
          return 0;
        }
      }
    
      function findCartHost() {
        var icon = document.querySelector('i.bx-cart, i.bx.bx-cart, .pi.pi-shopping-cart, i.pi-shopping-cart');
        if (!icon) return null;
        var host = icon.closest('a,button,div,span') || icon;
        return host;
      }
    
      function renderBadge() {
        var host = findCartHost();
        if (!host) return;
    
        var count = getCartCount();
        var badge = host.querySelector('.mirruba-cart-badge');
    
        if (!badge) {
          badge = document.createElement('span');
          badge.className = 'mirruba-cart-badge';
          badge.style.position = 'absolute';
          badge.style.top = '-8px';
          badge.style.right = '-10px';
          badge.style.minWidth = '18px';
          badge.style.height = '18px';
          badge.style.padding = '0 5px';
          badge.style.borderRadius = '999px';
          badge.style.background = '#d62828';
          badge.style.color = '#fff';
          badge.style.fontSize = '11px';
          badge.style.lineHeight = '18px';
          badge.style.fontWeight = '700';
          badge.style.textAlign = 'center';
          badge.style.zIndex = '9999';
          badge.style.pointerEvents = 'none';
          badge.style.boxShadow = '0 1px 4px rgba(0,0,0,.3)';
          if (getComputedStyle(host).position === 'static') {
            host.style.position = 'relative';
          }
          host.appendChild(badge);
        }
    
        if (count > 0) {
          badge.textContent = String(count > 99 ? '99+' : count);
          badge.style.display = 'block';
        } else {
          badge.style.display = 'none';
        }
      }
    
      var start = function () {
        renderBadge();
        setInterval(renderBadge, 700);
        window.addEventListener('storage', renderBadge);
        window.addEventListener('click', function () { setTimeout(renderBadge, 120); });
      };
    
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
      } else {
        start();
      }
    })();
    </script>
    <?php
}
add_action('wp_footer', 'mirruba_legacy_footer_scripts', 30);
